def faktorial(user):
    if user == 0:
        return 1
    else:
        return user * faktorial(user - 1)

while True:
    user = int(input("Masukkan bilangan bulat positif: "))

    if user < 0:
        print("Maaf, faktorial hanya untuk bilangan bulat positif dan tidak boleh negatif")
    else:
        hasil = faktorial(user)
        print("Faktorial dari", user ,"adalah ", hasil)

    ulangi = input("Apakah ingin menghitung lagi? (y/t): ")
    if ulangi.lower() != "y":
        break 