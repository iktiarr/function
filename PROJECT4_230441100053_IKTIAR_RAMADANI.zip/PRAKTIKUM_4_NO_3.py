def pangkat_dua(bilangan):
    if bilangan == 0:
        return 0
    elif bilangan == 1:
        return 1
    else:
        return bilangan * bilangan

while True:

    bilangan = int(input("Masukkan bilangan: "))

    hasil = pangkat_dua(bilangan)
    print(bilangan," pangkat dua adalah ",hasil)

    ulangi = input("Apakah ingin menghitung lagi? (y/t): ")
    if ulangi.lower() != "y":
        break 
