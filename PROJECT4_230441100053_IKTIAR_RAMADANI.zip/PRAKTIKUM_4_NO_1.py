def luas_kerucut():
    print("")
    print("===== Hitung Luas permukaan Kerucut =====")
    r = float(input("Masukkan jari-jari    : "))
    s = float(input("Masukkan garis pelukis: "))

    if r < 1 or s < 1:
        print("Angka harus lebih dari 1 atau tidak boleh negatif")
    elif r %7 == 0:
        luaskerucut = 22/7 * r * (s + r)
        print("Maka luas kerucut adalah ", luaskerucut )
    else:
        luaskerucut = 3.14 * r * (s + r)
        print("Maka luas kerucut adalah ", luaskerucut)
    
def luas_limassegilima():
    print("")
    print("===== Hitung luas permukaan limas segilima =====")
    s = float(input("Masukkan sisi      :"))
    sisitegak = float(input("Masukkan sisi tegak:"))

    if s < 1 or sisitegak < 1:
        print("Angka harus lebih dari 1 atau tidak boleh negatif")
    else: 
        luaslimassegilima = (1.72 * s * s) + (5 * sisitegak)
        print("Maka luas permukaan limas segilima adalah ", luaslimassegilima)

def luas_prismasegilima():
    print("")
    print("===== Hitung luas permukaan prisma segilima =====")
    la = float(input("Masukkan luas alas    : "))
    ka = float(input("Masukkan keliling alas: "))
    t = float(input("Masukkan tinggi prisma: "))

    if la < 1 or ka < 1 or t < 1:
        print("Angka harus lebih dari 1 atau tidak boleh negatif")
    else:
        luasprismasegilima = 2 * la + (ka + t)
        print("Maka luas permukaan prisma segilima adalah ", luasprismasegilima)

while True:
    print("Anda ingin menghitung apa???\n\n1. Hitung luas kerucut\n2. Hitung luas limas segilima\n3. Hitung prisma segilima\n0. Keluar\n ")
    user = int(input("Pilih rumus yang akan dicari: "))
    if (user == 1):
        luas_kerucut()
    elif (user == 2):
        luas_limassegilima()
    elif (user == 3):
        luas_prismasegilima()
    elif (user == 0):
        print(" TERIMA KASIH")
        break
    else:
        print("Pilihan tidak valid")